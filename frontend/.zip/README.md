#Group No- 37


Install Packages Using : npm i react-scripts\
run command : npx json-server -p 3001 -w db.json\
run command : npm start
